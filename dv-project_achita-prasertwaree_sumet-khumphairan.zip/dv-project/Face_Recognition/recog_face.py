#!/usr/bin/env python
########################################################################################################################################
#--------------------------------------------------------------------------------------1. Import necessary packages------------------------------------------------------------------------------------------------#
########################################################################################################################################
import argparse
import os
import sys
import torch
import torch.nn as nn

import utils
import datasets
import models.resnet as ResNet
from trainer import Trainer, Validator
from extractor import Extractor

########################################################################################################################################
#---------------------------------------------------------------------------------2. Hyperparameters and Helper Function--------------------------------------------------------------------------------------#
########################################################################################################################################

N_IDENTITY = 8631  # the number of identities in VGGFace2 for which ResNet are trained
configurations = { 
    1: dict(
        max_iteration=110, #number of epochs
        lr=1.0e-1, 
        momentum=0.9,
        weight_decay=0.0,
        gamma=0.1, #updating lr
        step_size=100, #used for decaying lr
        interval_validate=1 
    ),
}

def get_parameters(model, bias=False):
    for k, m in model._modules.items():
        if k == "fc" and isinstance(m, nn.Linear):
            if bias:
                yield m.bias #torch.Size([8631])
            else:
                yield m.weight #torch.Size([8631, 2048])


if torch.cuda.is_available():
    device = 'cuda'
else:
    device = 'cpu'
########################################################################################################################################
#---------------------------------------------------------------------------------------------------3. Main Function-----------------------------------------------------------------------------------------------------#
########################################################################################################################################
def main():
    #-----------------------------------------------------------------3.1 Adding arguments and also related directories--------------------------------------------------------------------------------#
    parser = argparse.ArgumentParser("Recognising Face with Pytorch")
    #options
    parser.add_argument('cmd', type=str,  choices=['train', 'test', 'extract'], help='train, test or extract')
    parser.add_argument('--model_type', type=str, default='resnet50_ft', help='model type')

    #directories
    parser.add_argument('--dataset_dir', type=str, default='vggface2/train_selected', help='train dataset directory')
    parser.add_argument('--te_dataset_dir', type=str, default='vggface2/test_selected', help='testing dataset directory') #on original
    #parser.add_argument('--te_dataset_dir', type=str, default='4_segmented_test', help='testing dataset directory') #on segmentation
    #text files
    parser.add_argument('--train_img_list_file', type=str, default='vggface2/train_selected_list.txt',
                        help='text file containing image files used for training')
    parser.add_argument('--test_img_list_file', type=str, default='vggface2/test_selected_list.txt',
                        help='text file containing image files used for validation, test or feature extraction')
   #identity file and weight file 
    parser.add_argument('--meta_file', type=str, default='vggface2/identity_meta.csv', help='meta file')
    parser.add_argument('--weight_file', type=str, default='models/resnet50_ft_weight.pkl', help='weight file')
    #log file, checkpoint, and feature extraction paths
    parser.add_argument('--log_file', type=str, default='0_logfile/logfile.txt', help='log file')
    parser.add_argument('--checkpoint_dir', type=str, default='1_checkpoint',
                        help='checkpoints directory')
    parser.add_argument('--feature_dir', type=str, default='2_feature/original',
                        help='directory where extracted features are saved')
    #others
    parser.add_argument('-c', '--config', type=int, default=1, choices=configurations.keys(),
                        help='the number of settings and hyperparameters used in training')
    parser.add_argument('--batch_size', type=int, default=32, help='batch size')
    parser.add_argument('--resume', type=bool, default=False, help='resuming process')
    parser.add_argument('--checkpoint_file', type=str, default='1_checkpoint/model_best.pth', help='checkpoint_file')
    parser.add_argument('--gpu', type=int, default=0)
    parser.add_argument('-j', '--workers', default=4, type=int, metavar='N',
                        help='number of data loading workers (default: 4)')
    parser.add_argument('--horizontal_flip', action='store_true', 
                        help='horizontally flip images specified in test_img_list_file')
    args = parser.parse_args()
    print(args)

    if args.cmd == "extract":
        utils.create_dir(args.feature_dir)
    if args.cmd == 'train':
        utils.create_dir(args.checkpoint_dir)
        cfg = configurations[args.config]

    log_file = args.log_file
    resume = args.resume

    os.environ['CUDA_VISIBLE_DEVICES'] = str("0,1") 
    cuda = torch.cuda.is_available()
    if cuda:
        print("torch.backends.cudnn.version: {}".format(torch.backends.cudnn.version()))
    torch.manual_seed(1337)
    if cuda:
        torch.cuda.manual_seed(1337)

    #-------------------------------------------------------------3.2 Import meta file (.csv) and then get the label for each image--------------------------------------------------------------------#
    meta_file = args.meta_file
    id_label_dict = utils.get_id_label_map(meta_file)

    #----------------------------------------------------------------------------3.3 Make data loader for training and testing-------------------------------------------------------------------------------#
    train_root  = args.dataset_dir
    test_root = args.te_dataset_dir
    
    train_img_list_file = args.train_img_list_file
    test_img_list_file = args.test_img_list_file

    kwargs = {'num_workers': args.workers, 'pin_memory': True} if cuda else {}

    if args.cmd == 'train':
        training_set = datasets.VGG_Faces2(train_root, train_img_list_file, id_label_dict, split='train')
        train_loader = torch.utils.data.DataLoader(training_set, batch_size=args.batch_size, shuffle=True, **kwargs)

    testing_set = datasets.VGG_Faces2(test_root, test_img_list_file, id_label_dict, split='valid',
                             horizontal_flip=args.horizontal_flip)
    val_loader = torch.utils.data.DataLoader(testing_set, batch_size=args.batch_size, shuffle=False, **kwargs)

    #-----------------------------------------------------------------------------------------3.4 Load resnet50 model---------------------------------------------------------------------------------------------#
    include_top = True if args.cmd != 'extract' else False
    model_type = args.model_type
    if 'resnet' in model_type:
        model = ResNet.resnet50(args.weight_file, num_classes=N_IDENTITY)  # Pretrained weights fc layer has 8631 outputs
    
    start_epoch = 0
    start_iteration = 0
    resume = args.resume
    checkpoint_file = args.checkpoint_file
    if resume: 
        checkpoint = torch.load(checkpoint_file)
        model.load_state_dict(checkpoint['model_state_dict'])
        start_epoch = checkpoint['epoch']
        start_iteration = checkpoint['iteration']
        assert checkpoint['arch'] == "ResNet"
        print("Resume from epoch: {}, iteration: {}".format(start_epoch, start_iteration))
    else:
        utils.load_state_dict(model, args.weight_file)
        if args.cmd == 'train':
            model.fc.reset_parameters()
            
    if cuda:
        model = model.to(device)
    #---------------------------------------------------------------------------------3.5 Loss function to be minimized-----------------------------------------------------------------------------------------#
    criterion = nn.CrossEntropyLoss()
    if cuda:
        criterion = criterion.to(device)

    #------------------------------------------------------------------------------------3.6 Set SGD as our optimizer--------------------------------------------------------------------------------------------#
    if args.cmd == 'train':
        optim = torch.optim.SGD(
            [
                {'params': get_parameters(model, bias=False)},
                {'params': get_parameters(model, bias=True), 'lr': cfg['lr'] * 2, 'weight_decay': 0},
            ],
            lr=cfg['lr'],
            momentum=cfg['momentum'],
            weight_decay=cfg['weight_decay'])
        if resume:
            optim.load_state_dict(checkpoint['optim_state_dict'])
    
        last_epoch = start_iteration if resume else -1
        lr_scheduler = torch.optim.lr_scheduler.StepLR(optim,  cfg['step_size'],
                                                       gamma=cfg['gamma'], last_epoch=last_epoch)
    #---------------------------------------------------------------------------------3.7 Training, Testing or Extracting-----------------------------------------------------------------------------------------#
    if args.cmd == 'train':
        trainer = Trainer(
            cmd=args.cmd,
            cuda=cuda,
            model=model,
            criterion=criterion,
            optimizer=optim,
            lr_scheduler=lr_scheduler,
            train_loader=train_loader,
            val_loader=val_loader,
            log_file=log_file,
            max_iter=cfg['max_iteration'],
            checkpoint_dir=args.checkpoint_dir,
            print_freq=1,
        )
        trainer.epoch = start_epoch
        trainer.iteration = start_iteration
        trainer.train()
        
    elif args.cmd == 'test':
        validator = Validator(
            cmd=args.cmd,
            cuda=cuda,
            model=model,
            criterion=criterion,
            val_loader=val_loader,
            log_file=log_file,
            print_freq=1,
        )
        validator.validate()
    elif args.cmd == 'extract':
        extractor = Extractor(
            cuda=cuda,
            model=model,
            val_loader=val_loader,
            log_file=log_file,
            feature_dir=args.feature_dir,
            flatten_feature=True,
            print_freq=1,
        )
        extractor.extract()


if __name__ == '__main__':
    main()
