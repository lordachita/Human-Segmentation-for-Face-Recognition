import torch.utils.data as data

from PIL import Image
import os
import os.path


def default_loader(path):
    return Image.open(path)

class CelebA(data.Dataset):
    def __init__(self, root, transform=None, target_transform=None,
                 loader=default_loader):
        imgs = root
        self.imgs = imgs
        self.transform = transform
        self.target_transform = target_transform
        self.loader = loader

    def __getitem__(self, index):
        front, back = self.imgs[index]
        img = self.loader(front).convert('RGB')
        target = self.loader(back)
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target

    def __len__(self):
        return len(self.imgs)
